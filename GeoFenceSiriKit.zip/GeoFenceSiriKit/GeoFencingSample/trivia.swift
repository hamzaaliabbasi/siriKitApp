//
//  trivia.swift
//  GeoFencingSample
//
//  Created by Tpl Life 02 on 24/04/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Foundation
import  GoogleMaps
import Alamofire
import Intents
class trivia {
//    static let shared = trivia()
    static let locationManager = CLLocationManager()
        func siriHandler(handler: @escaping (String) -> Void){
            Alamofire.request("http://numbersapi.com/random/trivia").responseString{(triviaResponse) in
                if let trivia = triviaResponse.value
                {
                    handler(trivia)
                }
                
            }
    
 
    }
    
               
    
}
