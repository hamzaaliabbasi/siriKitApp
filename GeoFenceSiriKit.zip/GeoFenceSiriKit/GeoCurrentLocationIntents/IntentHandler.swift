//
//  IntentHandler.swift
//  GeoCurrentLocationIntents
//
//  Created by Tpl Life 02 on 24/04/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import Intents
import AVFoundation
class GetLocationIntentHandler: NSObject, GetLocationIntentHandling{
   
    func confirm(intent: GetLocationIntent, completion: @escaping (GetLocationIntentResponse) -> Void) {
        completion(GetLocationIntentResponse(code: .ready, userActivity: nil))
    }
    func handle(intent: GetLocationIntent, completion: @escaping (GetLocationIntentResponse) -> Void) {
        
        print("intent")
        var x = ""

        trivia().siriHandler{triviaa in
            completion(.success(currentLocation: triviaa))
        }
//            DispatchQueue.main.async {
//                x = "Latitude:" + String(Double((trivia.locationManager.location?.coordinate.latitude)!)) + " Longitude:"  + String(Double((trivia.locationManager.location?.coordinate.longitude)!))
//
//                completion( .success(currentLocation:x))
//                print(x)
//            }
    
    
 
    
    }
    
}//Class Ends   §

class IntentHandler: INExtension {
    
    override func handler(for intent: INIntent) -> Any {
        guard intent is GetLocationIntent else{
            fatalError("Unhandled Intent")
        }
        return GetLocationIntentHandler()
        
    }
    
}

